# Ans_To_Icoding
As the end of C programming class approaching, here's a project for studying communication!  
It's just for `communication`, `never just copy it`, and if you like it, please give me a "watch" and a "star" as well!  
More communicators are welcomed to this page!  
If you don't mind, contribute by following ways and `let's make a friend`!  
<img src="https://github.com/fessorpro-30/Ans_To_Icoding/raw/master/1576944081.jpg" alt="AliPay" width="250" height="400">
<img src="https://github.com/fessorpro-30/Ans_To_Icoding/raw/master/mm_facetoface_collect_qrcode_1576944123897.png" alt="WeChat" width="250" height="400">
